﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.SqlClient;
using WebApplication1.Models;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace WebApplication1.Controllers
{
    public class CategorysController : ApiController
    {
        public HttpResponseMessage Get()
        {
            string q = @"select * from dbo.Category";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(@"Data Source = .\SQLEXPRESS ; Initial Catalog=Task ; Integrated Security = true"))
            using (var cam = new SqlCommand(q, con))
            using (var qa = new SqlDataAdapter(cam))
            {
                cam.CommandType = CommandType.Text;
                qa.Fill(table);

            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        public string post(Category c)
        {
            try {
                string q = "insert into dbo.Category values ('" + c.name + "')";
                    DataTable table = new DataTable();
                using (var con = new SqlConnection(@"Data Source = .\SQLEXPRESS ; Initial Catalog=Task ; Integrated Security = true"))
                using (var cam = new SqlCommand(q, con))
                using (var qa = new SqlDataAdapter(cam))
                {
                    cam.CommandType = CommandType.Text;
                    qa.Fill(table);

                }


                return "Insert Success";
            }catch(Exception e)
            {
                return "Failed to Insert";
            }


        }
        public string put (Category c)
        {
            try
            {
                string q = "Update dbo.Category set name = '" + c.name + "'";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(@"Data Source = .\SQLEXPRESS ; Initial Catalog=Task ; Integrated Security = true"))
                using (var cam = new SqlCommand(q, con))
                using (var qa = new SqlDataAdapter(cam))
                {
                    cam.CommandType = CommandType.Text;
                    qa.Fill(table);

                }

                return "Success Update";
            }catch(Exception e)
            {
                return "Update Failed";
            }
        }
        [HttpDelete]
        [OperationContract]
        [WebInvoke(
            Method="DELETE",
            UriTemplate="/api/categorys/{id}"
            )]
        public Boolean Delete (String id)
        {
            try
            {
                string q = @"delete from dbo.Category where id = "+id+" ";
                DataTable table = new DataTable();
                using (var con = new SqlConnection(@"Data Source = .\SQLEXPRESS ; Initial Catalog=Task ; Integrated Security = true"))
                using (var cam = new SqlCommand(q, con))
                using (var qa = new SqlDataAdapter(cam))
                {
                    cam.CommandType = CommandType.Text;
                    qa.Fill(table);

                }
                return true;

             
            }
            catch(Exception e)
            {
                return false;
            } 
        }
    }
}
